function [LSI1,LSI2,Vm,PTloss,QTloss]=pf_34(start,x)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Network_data_34;

S_base=100000;   %(kVA)
V_base=11; %(kV)
Z_base=1000*(V_base^2)/(S_base);
I_base=S_base/(sqrt(3)*V_base);
if start==1
for i=1:numel(x)/2
    bus_data(x(i),3)=bus_data(x(i),3)-x(i+(numel(x)/2));   
end
elseif start==2
    for i=1:numel(x)/2
        if x(i+(numel(x)/2))>0 && x(i+(numel(x)/2))<=0.125
            x(i+(numel(x)/2))=150;
        elseif x(i+(numel(x)/2))>0.125 && x(i+(numel(x)/2))<=0.25
            x(i+(numel(x)/2))=300;
        elseif x(i+(numel(x)/2))>0.25 && x(i+(numel(x)/2))<=0.375
            x(i+(numel(x)/2))=450;
        elseif x(i+(numel(x)/2))>0.375 && x(i+(numel(x)/2))<=0.5
            x(i+(numel(x)/2))=600;
        elseif x(i+(numel(x)/2))>0.5 && x(i+(numel(x)/2))<=0.625
            x(i+(numel(x)/2))=750;
        elseif x(i+(numel(x)/2))>0.625 && x(i+(numel(x)/2))<=0.75
            x(i+(numel(x)/2))=900;
        elseif x(i+(numel(x)/2))>0.75 && x(i+(numel(x)/2))<=0.875
            x(i+(numel(x)/2))=1050;
        elseif x(i+(numel(x)/2))>0.875
            x(i+(numel(x)/2))=1200;
        end
    end
for i=1:numel(x)/2
 bus_data(x(i),3)=bus_data(x(i),3)-x(i+(numel(x)/2)); 
end

end

demanded_P=bus_data(:,2)/S_base;
demanded_Q=bus_data(:,3)/S_base;
R=line_data(:,3)/Z_base;
X=line_data(:,4)/Z_base;
nbus=length(bus_data);
nline=length(line_data);
%% calculating configuration matrix of network

from=line_data(:,1);
to=line_data(:,2);

a=from;
b=to;
w=line_data(:,3);
u=max(max(a),max(b));
DG = sparse(a,b,w,u,u); 
pathMAT=graphallshortestpaths(DG);

if start == 0
view(biograph(DG,[],'ShowWeights','on'))
end

for k=1:length(pathMAT)
    for kk=1:length(pathMAT)
        if (pathMAT(k,kk)==inf)
            pathMAT(k,kk)=0;
        end
    end
end
for k=1:length(pathMAT)
    for kk=1:length(pathMAT)
        if (pathMAT(k,kk)~=0)
            pathMAT(k,kk)=1;
        end
    end
end
% pathMAT(12,12)=1;
% pathMAT(30,30)=1;
% pathMAT(16,16)=1;
% pathMAT(27,27)=1;
% pathMAT(34,34)=1;
BIBC=pathMAT;
%% Initilize voltage 
for i=1:nbus
Vm(1,i)=1;   %voltage magnitude(pu)
end

%% start iteration
delta=1;eps=0.00001;iter=0;
MAXiter=1000;
while delta > eps
iter=iter+1;
if iter>MAXiter
    
    break;
end
for k=1:nbus
        Ibus(k,1)=(demanded_P(k,1)-sqrt(-1).*demanded_Q(k,1))./(conj(Vm(k)));
end
Inode=BIBC*Ibus;

V(1)=1;
for k=1:length(line_data)
   V(line_data(k,2))=Vm(line_data(k,1))-(R(k,1)+sqrt(-1)*X(k,1))*(Inode(line_data(k,2),1)+Ibus(line_data(k,2),1));
end
delta=max(abs(V-Vm));
Vm=V;
end
%abs(Vm)
%% results 
%hold on
if start==0
figure(1)
plot(abs(Vm),'--*b')
ylabel('Voltage Magnitude (p.u.)')
xlabel('Bus Number')
title('Vlotage profile')
end
%% loss calculation
for k=1:length(line_data)
        IL(k)=abs((Vm(line_data(k,1))-Vm(line_data(k,2)))./(R(k,1)+sqrt(-1).*X(k,1))).*I_base;
end
    for k=1:length(line_data)
        Loss(k)=3*((R(k,1)).*Z_base).*((IL(k)).^2);
        QLoss(k)=3*((X(k,1)).*Z_base).*((IL(k)).^2);
    end
    
%%%%%%%%%%%%%%% loss sensitivity index %%%%%%%%%%%%
LSI1=-2*((demanded_P(2:end)+Loss'/S_base).^2+(demanded_Q(2:end)+QLoss'/S_base).^2).*(R(k,1).*Z_base)./(abs(Vm(1,2:end)).^3)';
% LSI1=-2*(demanded_P(2:end).^2+demanded_Q(2:end).^2).*(R(k,1).*Z_base)./(abs(Vm(1,2:end)).^3)';
[Value1,Index1]=sort(LSI1);
Index1=Index1+1;
LSI1=[Value1,Index1];
    
LSI2=2*((demanded_Q(2:end)+QLoss'/S_base).^2).*(R(k,1).*Z_base)./(abs(Vm(1,2:end)).^2)';
[Value2,Index2]=sort(LSI2,'descend');
Index2=Index2+1;
LSI2=[Value2,Index2];

PTloss=0;
QTloss=0;
for k=1:length(Loss)
    PTloss=PTloss+Loss(k);
    QTloss=QTloss+QLoss(k);
end
PTloss=PTloss/1000;
QTloss=QTloss/1000;